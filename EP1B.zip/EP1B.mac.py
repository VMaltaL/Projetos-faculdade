# -*- coding: utf-8 -*-
"""
Nome do aluno: Victoria Malta Pereira de Lima
     Número USP: 10789301
     Curso: Geofísica
     Disciplina: MAC0115  Introdução à Computação
     Exercício-Programa EP1B

          DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA. 
     TODAS AS PARTES ORIGINAIS DESTE EXERCÍCIO-PROGRAMA FORAM
     DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES
     DESSE EP E QUE PORTANTO NÃO CONSTITUEM DESONESTIDADE ACADÊMICA
     OU PLÁGIO.
         DECLARO TAMBÉM QUE SOU RESPONSÁVEL POR TODAS AS CÓPIAS DESTE
     PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A SUA DISTRIBUIÇÃO.
     ESTOU CIENTE QUE OS CASOS DE PLÁGIO E DESONESTIDADE ACADÊMICA SERÃO
     TRATADOS SEGUNDO OS CRITÉRIOS DIVULGADOS NA PÁGINA DA DISCIPLINA.
  
         Este Ep foi feito apenas com conteúdo passado durante a aula ou 
    disponibilizado na página da disciplina do moodle.
"""

print("\nEsse programa calcula se um numero dado, n, é a soma de três números primos consecutivos.")


#------------------------------------------------------------------------------
#                           Função principal
#------------------------------------------------------------------------------


def main():
    
    n = int(input("Insira um número inteiro positivo para n: "))

    nat = 1
    soma = 0 #soma dos últimos primos
    p = 0 #penúltimo primo
    u = 0 #último primo
    a = 0 #atual
    
    while soma < n:
    
        if eh_primo(nat):
            p = u
            u = a
            a = nat
            
            soma = p + u + a
            
        nat += 1
            

    
    if soma == n and u != 0 and p != 0:
        print (".\nO número", n, "é a soma de três números primos consecutivos.") 
        print ("São eles: %d, %d e %d." %(p,u,a))
    
    else:
        print("O número", n, "não é a soma de três números primos consecutivos.")


#------------------------------------------------------------------------------
#                     função descobre se um número é primo
#------------------------------------------------------------------------------


def eh_primo(n):
    if n == 2:
        primo = True
        
    else: 
        if n == 1 or n % 2 == 0:
            primo = False
            
        else:
            
            nat = 3
            primo = True
            
            while nat * nat <= n and primo:
                
                if n % nat == 0:
                    
                    primo = False
                nat += 2
                
    return primo


#------------------------------------------------------------------------------
#                 Chama a função principal
#------------------------------------------------------------------------------
    

main()
