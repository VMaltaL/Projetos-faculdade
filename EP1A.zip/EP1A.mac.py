# -*- coding: utf-8 -*-
"""
Nome do aluno: Victoria Malta Pereira de Lima
     Número USP: 10789301
     Curso: Geofísica
     Disciplina: MAC0115  Introdução à Computação
     Exercício-Programa EP1A

          DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA. 
     TODAS AS PARTES ORIGINAIS DESTE EXERCÍCIO-PROGRAMA FORAM
     DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES
     DESSE EP E QUE PORTANTO NÃO CONSTITUEM DESONESTIDADE ACADÊMICA
     OU PLÁGIO.
         DECLARO TAMBÉM QUE SOU RESPONSÁVEL POR TODAS AS CÓPIAS DESTE
     PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A SUA DISTRIBUIÇÃO.
     ESTOU CIENTE QUE OS CASOS DE PLÁGIO E DESONESTIDADE ACADÊMICA SERÃO
     TRATADOS SEGUNDO OS CRITÉRIOS DIVULGADOS NA PÁGINA DA DISCIPLINA.
  
         Este Ep foi feito apenas com conteúdo passado durante a aula ou 
    disponibilizado na página da disciplina do moodle.
"""

print("Este programa calcula o F(n) de uma sequência de Trinacci, dado o n pelo usuário.")

a = 0 #F(n-3) ou F(n)
b = 1 #F(n-2) ou F(n+1)
c = 1 #F(n-1) ou F(n+2)
n = int(input("Insira o número inteiro maior ou igual a 0 para n:" ))

cont = 0 #contador


while cont < n:
    d = a + b + c #calcula F(cont)
    
    #atualiza as variáveis 
    a = b
    b = c
    c = d
    cont = cont + 1
    
print ("\nO F(",n,") da sequência de Trinacci é ", a, sep = "", end = ".\n")

#imprime somente o termo que estamos interessados, f(n).
"""
Usando cont = 0, estamos na verdade sempre interessados no F(a).
"""
